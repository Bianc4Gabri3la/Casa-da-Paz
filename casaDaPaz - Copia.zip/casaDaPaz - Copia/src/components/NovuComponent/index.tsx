

export const NovuComponent = () => {
    return(
        <h1 className="title">Novu component</h1>
    )
}